﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Collections;
using System.Threading;
using System.Runtime.InteropServices;

namespace Cliente_v2
{
    public partial class Cliente : Form
    {
        Socket server;
        Thread atender;
        string invitacion;
        bool salacreada;
        delegate void DelegadoParaActualizar(string trozos);
        public Cliente()
        {
            InitializeComponent();
            //CheckForIllegalCrossThreadCalls = false;
            
            bm =new Bitmap(pic.Width,pic.Height);
            g=Graphics.FromImage(bm);
            g.Clear(Color.White);
            pic.Image = bm;
        }


        private void atenderServidor()
        {
            while (true)
            {
                //mensaje que llega desde el servidor
                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                string[] trozos = Encoding.ASCII.GetString(msg2).Split('/');
                int codigo = Convert.ToInt32(trozos[0]);
                string mensaje = trozos[1].Split('\0')[0];

                switch (codigo)
                {
                    case 1: //respusta cuando intentamos iniciar sesión
                        /*Recibimos la respuesta del servidor, que sera SI o NO, ..., Si es si se mostrara un mensaje en pantalla y 
                        se pasara al formulario de consultas, si sale no saldra un mensaje con un error*/

                        if (mensaje == "SI") //MENSAJE TIENE QUE SER 'SI'
                        {
                            MessageBox.Show("Sesión Iniciada");
                            //para que el usuario no vuelva a inciar o registrarse, ya que ya estara registrado
                            iniciar_sesion.Visible = false;
                            registrarse.Visible = false;
                        }
                        else if (mensaje == "incorrectPass")
                        {
                            MessageBox.Show("Error al iniciar sesión, pruebe nombre o contraseña erroneos");

                        }
                        else if (mensaje == "noUser")
                        {
                            MessageBox.Show("Error al inciar sesión, no existe el usuario introducido");
                        }
                        else if (mensaje == "yaConectado")
                        {
                            MessageBox.Show("El usuario ya esta conectado a nuestro servidor");
                        }
                        break;
                    case 2: //respuesta cuando nos intentamos registrar
                        /*Recibimos la respuesta del servidor, que sera SI o NO, Si es si se mostrara un mensaje en pantalla y 
                        se pasara al formulario de inicio de sesion, si sale no saldra un mensaje con un error*/

                        if (mensaje == "SI") //MENSAJE TIENE QUE SER 'SI'
                        {
                            MessageBox.Show("Registro completado");
                        }
                        else if (mensaje == "NO")
                        {
                            MessageBox.Show("Error al completar registro, pruebe con otro nombre y contraseña");
                        }
                        else if (mensaje == "EXISTE")
                        {
                            MessageBox.Show("El usuario que has introducido ya existe");
                        }
                        break;

                    case 3:
                        MessageBox.Show("El jugador con más partidas ha ganado más en el escenario: " + mensaje);//Mensaje sera el nombre del escenario
                        break;
                    case 4:
                        mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                        MessageBox.Show("Ha ganado el jugador" + mensaje);//Mensaje tiene el nombre del jugador ganador
                        break;
                    case 5:
                        mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                        MessageBox.Show("El jugador que ha perdido la partida mas larga contra: " + mensaje);
                        //Mensaje debera tener un formato JugadorPerdedor-JugadorGanador
                        break;
                    case 6:
                        /*int num = Convert.ToInt32(trozos[1]);
                        int i = 0;
                        LC.Rows.Clear();
                        while (i < num)
                        {
                            LC.Rows.Add(trozos[i + 2], "0");
                            i++;
                        }*/

                        //L5
                        DelegadoParaActualizar delegado = new DelegadoParaActualizar(actualizarlista);
                        LC.Invoke(delegado, new object[] {trozos});
                        break;
                    /*case 7:
                        if (salacreada = true)
                            MessageBox.Show("Ya se encuentra en una sala");
                        else

                            numsala.Text(trozos[x]);
                            salacreada = true;

                        break:*/
                    /*case 8:
                        invitacion = trozos[1];
                        chat.Text(invitacion + "quiere invitarte a tu sala");
                        
                        break;*/

                }
            }
        }

        private void conectar_Click(object sender, EventArgs e)
        {
            IPAddress direc = IPAddress.Parse("192.168.56.102"); //INDICAMOS IP// La ip establecida es un ejemplo
            IPEndPoint ipep = new IPEndPoint(direc, 9050); //INDICAMOS PUERTO// El puerto establecido es un ejemplo

            //Creamos el socket
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep); //Intentamos conectar el socket
            }
            catch (SocketException ex)
            {
                //Si hay excepcion indicamos error y salimos del programa con un return
                MessageBox.Show("Conexion con servidor fallida: " + ex.Message);
                return;
            }

            ThreadStart ts = delegate { atenderServidor(); };
            atender = new Thread(ts);
            atender.Start();

            //cambia el texto de los labels para informar al usuario, ademas desactiva o activa botones para evitar errores y que el usuario sepa que puede hacer
            estado.Text = "Conectado";
            desconectar.Enabled = true;
            conectar.Enabled = false;
            iniciar_sesion.Enabled = true;
            registrarse.Enabled = true;
        }

        private void desconectar_Click(object sender, EventArgs e)
        {
            //Mensaje de desconexion
            string mensaje = "0/"; //codigo 0 para desconectar
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Nos desconectamos
            atender.Abort();
            this.BackColor = Color.Gray;
            server.Shutdown(SocketShutdown.Both);
            server.Close();

            

            //cambia el texto de los labels para informar al usuario, ademas desactiva o activa botones para evitar errores y que el usuario sepa que puede hacer
            estado.Text = "Desconectado";
            iniciar_sesion.Visible = true;
            registrarse.Visible = true;
            desconectar.Enabled = false;
            conectar.Enabled = true;
            iniciar_sesion.Enabled = false;
            registrarse.Enabled = false;
        }

        private void iniciar_sesion_Click(object sender, EventArgs e)
        {
            string mensaje = "1/" + textUsuario.Text + "/" + textPassword.Text; /*EL mensaje 1 servira para iniciar sesion, el servidor tendra que
            buscar en la base de datos al usuario y enviar un mensaje de vuelta que ponga que SI esta. */

            //antes de enviar se comprobara que el usuario ha introducido correctamente los campos necesarios
            if ((textUsuario.Text != "") && (textPassword.Text != ""))
            {
                // Enviamos al servidor el nombre y contraseña de teclado
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
            else
            {
                MessageBox.Show("Introduzca un usuario o contraseña");
            }
        }

        private void registrarse_Click(object sender, EventArgs e)
        {
            string mensaje = "2/" + textUsuario.Text + "/" + textPassword.Text; /*EL mensaje 2 servira para registrarse, el servidor tendra que
            insertar en la base de datos al usuario y enviar un mensaje de vuelta que lo verifique. */

            //antes de enviar se comprobara que el usuario ha introducido correctamente los campos necesarios
            if ((textUsuario.Text != "") && (textPassword.Text != ""))
            {
                // Enviamos al servidor el nombre y contraseña de teclado
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
            else
            {
                MessageBox.Show("Introduzca un usuario o contraseña");
            }
        }

        private void enviar_Click(object sender, EventArgs e)
        {
            if (consulta1.Checked)
            {
                string mensaje = "3/";
                // Enviamos al servidor la consulta para la DB
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
            else if (consulta2.Checked)
            {
                string mensaje = "4/" + jugador1.Text + "/" + jugador2.Text;
                // Enviamos al servidor la consulta para la DB
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }

            else if (consulta3.Checked)
            {
                string mensaje = "5/";
                // Enviamos al servidor la consulta para la DB
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
        }
        private void button4_Click(object sender, EventArgs e)//solicitud para crear la sala
        {
            string mensaje = "6/" + nombreinv.Text;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        private void button5_Click(object sender, EventArgs e)//Enviamos la solicitud para invitar a la sala
        {
            if (salacreada == false)
                MessageBox.Show("Se ha de crear una sala primero");
            else
            {
                string mensaje = "7/" + nombreinv.Text;
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);
            }
        }
        private void aceptar_Click(object sender, EventArgs e)
        {
            string mensaje = "8/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }

        private void rechazar_Click(object sender, EventArgs e)
        {
            string mensaje = "9/" + invitacion;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);
        }
        public void actualizarlista(string trozos)
        {
            string[] nombres = trozos.Split('/');
            int num = Convert.ToInt32(nombres[1]);
            int i = 0;
            LC.Rows.Clear();
            while (i < num)
            {
                LC.Rows.Add(nombres[i + 2], "0");
                i++;
            }
        }























        Bitmap bm;
        Graphics g;
        bool paint = false;
        Point px, py;
        Pen p = new Pen(Color.Black, 1);
        Pen erase=new Pen(Color.White, 50);
        int index;
        int x, y, sX, sY, cX, cY;

        ColorDialog cd = new ColorDialog();
        Color new_color;
        private void button3_Click(object sender, EventArgs e)
        {
            g.Clear(Color.White);
            pic.Image = bm;
            index = 0;

        }

        private void btn_color_Click(object sender, EventArgs e)
        {
            cd.ShowDialog();
            new_color = cd.Color;
            pic_color.BackColor = cd.Color;
            p.Color = cd.Color;
        }

        private void pic_MouseDown(object sender, MouseEventArgs e)
        {
            paint = true;
            py = e.Location;

            
        }

        private void color_picker_MouseClick(object sender, MouseEventArgs e)
        {
            Point point = set_point(color_picker, e.Location);
            pic_color.BackColor=((Bitmap)color_picker.Image).GetPixel(point.X, point.Y);
            new_color = pic_color.BackColor;
            p.Color = pic_color.BackColor;
        }

        

        private void pic_MouseMove(object sender, MouseEventArgs e)
        {
            if(paint==true)
            {
                if(index==1)
                {
                    px = e.Location;
                    g.DrawLine(p,px,py);
                    py = px;


                }
                if (index == 2)
                {
                    px = e.Location;
                    g.DrawLine(erase, px, py);
                    py = px;


                }
            }
            pic.Refresh();
        }
        private void pic_MouseUp(object sender, MouseEventArgs e)
        {
            paint=false;
        }

        private void btn_eraser_Click(object sender, EventArgs e)
        {
            index = 2;
        }

        private void btn_pencil_Click(object sender, EventArgs e)
        {
            index = 1;
        }
        private void pic_Paint(object sender, PaintEventArgs e)
        {

        }
        static Point set_point(PictureBox pb, Point pt)
        {
            float px = 1f*pb.Image.Width/ pb.Width;
            float py = 1f*pb.Image.Height/ pb.Height;
            return new Point((int)(pt.X*px), (int)(pt.Y*py));
        }

    }

}

